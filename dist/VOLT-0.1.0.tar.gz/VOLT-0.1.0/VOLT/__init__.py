"""
VOLT

An efficient token vocabulary construction method.
"""

__version__ = "0.1.0"
__author__ = 'Jingjing Xu'
__credits__ = 'ByteDance AI Lab, University of Wisconsin-Madison Math Departmenet, Nanjing University'